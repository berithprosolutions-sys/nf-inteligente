// SCRIPT: seed
// Responsabilidade: Popular o banco com dados de desenvolvimento realistas
// Executar: pnpm db:seed
import 'dotenv/config';
import { PrismaClient, OrigemMercadoria } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed do banco de dados...');

  // 1. Empresa de teste
  const empresa = await prisma.empresa.upsert({
    where: { cnpj: '11.222.333/0001-81' },
    update: {},
    create: {
      razaoSocial: 'Berith Tecnologia LTDA',
      nomeFantasia: 'Berith Tech',
      cnpj: '11.222.333/0001-81',
      regimeTributario: 'SimplesNacional',
      uf: 'SP',
      municipio: 'São Paulo',
      codigoMunicipio: '3550308',
      inscricaoEstadual: '111.222.333.444',
      inscricaoMunicipal: '1.234.567-8',
      plano: 'pro',
      enderecoCompleto: {
        logradouro: 'Av. Paulista',
        numero: '1000',
        bairro: 'Bela Vista',
        cep: '01310-100',
        municipio: 'São Paulo',
        uf: 'SP',
      },
    },
  });
  console.log(`✅ Empresa criada: ${empresa.razaoSocial}`);

  // 2. Usuário owner
  const passwordHash = await bcrypt.hash('senha123', 12);
  const usuario = await prisma.usuario.upsert({
    where: { email: 'dev@berith.com.br' },
    update: {},
    create: {
      nome: 'Marco Antônio',
      email: 'dev@berith.com.br',
      passwordHash,
      role: 'OWNER',
      empresaId: empresa.id,
    },
  });
  console.log(`✅ Usuário criado: ${usuario.email}`);

  // 3. Clientes
  const clientes = [
    {
      tipo: 'PJ' as const,
      documento: '22.333.444/0001-72',
      nome: 'Indústria Metalúrgica Paulista LTDA',
      email: 'vendas@metalpaulista.com.br',
      uf: 'SP',
      enderecoCompleto: { logradouro: 'Rua Industrial', numero: '500', bairro: 'Cidade Industrial', cep: '06000-000', municipio: 'Osasco', uf: 'SP' },
    },
    {
      tipo: 'PJ' as const,
      documento: '33.444.555/0001-63',
      nome: 'Distribuidora Minas Online EIRELI',
      email: 'compras@distminas.com.br',
      uf: 'MG',
      enderecoCompleto: { logradouro: 'Av. do Contorno', numero: '2000', bairro: 'Centro', cep: '30110-927', municipio: 'Belo Horizonte', uf: 'MG' },
    },
    {
      tipo: 'PF' as const,
      documento: '529.982.247-25',
      nome: 'Carlos Eduardo Silva',
      email: 'carlos.silva@mail.com',
      uf: 'SP',
      enderecoCompleto: { logradouro: 'Rua das Flores', numero: '45', bairro: 'Jardim Primavera', cep: '08000-000', municipio: 'São Paulo', uf: 'SP' },
    },
  ];

  for (const c of clientes) {
    await prisma.cliente.upsert({
      where: { id: `seed-${c.documento.replace(/\D/g, '')}` },
      update: {},
      create: {
        id: `seed-${c.documento.replace(/\D/g, '')}`,
        ...c,
        empresaId: empresa.id,
      },
    });
  }
  console.log(`✅ ${clientes.length} clientes criados`);

  // 4. Produtos
  const produtos = [
    {
      id: 'seed-prod-001',
      nome: 'Notebook Dell Latitude 5540',
      ncm: '84713019',
      ncmConfirmado: true,
      aliquotaIpi: 0,
      fonteLegal: 'TIPI 2024 - DECRETO nº 11.158/2022',
      unidade: 'UN',
      valorUnitario: 4800,
      origemMercadoria: OrigemMercadoria.CODIGO_0,
    },
    {
      id: 'seed-prod-002',
      nome: 'Monitor LG 27" UHD',
      ncm: '85285220',
      ncmConfirmado: true,
      aliquotaIpi: 15,
      fonteLegal: 'TIPI 2024 - EXC 01 - DECRETO nº 11.158/2022',
      unidade: 'UN',
      valorUnitario: 1200,
      origemMercadoria: OrigemMercadoria.CODIGO_0,
    },
    {
      id: 'seed-prod-003',
      nome: 'Teclado Mecânico Keychron K2',
      ncm: '84716052',
      ncmConfirmado: true,
      aliquotaIpi: 10,
      fonteLegal: 'TIPI 2024',
      unidade: 'UN',
      valorUnitario: 350,
      origemMercadoria: OrigemMercadoria.CODIGO_1,
    },
  ];

  for (const p of produtos) {
    await prisma.produto.upsert({
      where: { id: p.id },
      update: {},
      create: { ...p, empresaId: empresa.id },
    });
  }
  console.log(`✅ ${produtos.length} produtos criados`);

  // 5. Serviços
  const servicos = [
    {
      id: 'seed-serv-001',
      nome: 'Desenvolvimento e Licenciamento de Software',
      codigoLC116: '1.01',
      lc116Confirmado: true,
      aliquotaISSQN: 2.0,
    },
    {
      id: 'seed-serv-002',
      nome: 'Consultoria em Tecnologia da Informação',
      codigoLC116: '17.01',
      lc116Confirmado: true,
      aliquotaISSQN: 5.0,
    },
  ];

  for (const s of servicos) {
    await prisma.servico.upsert({
      where: { id: s.id },
      update: {},
      create: { ...s, empresaId: empresa.id },
    });
  }
  console.log(`✅ ${servicos.length} serviços criados`);

  // 6. NCMs base (TIPI 2024)
  const ncms = [
    { codigo: '84713019', descricao: 'Máquinas automáticas para processamento de dados, portáteis', aliquotaIpi: 0, unidadeTributavel: 'UN', fonteLegal: 'TIPI 2024 - DECRETO nº 11.158/2022' },
    { codigo: '85285220', descricao: 'Monitores do tipo utilizado em máquinas automáticas para processamento de dados', aliquotaIpi: 15, unidadeTributavel: 'UN', fonteLegal: 'TIPI 2024 EXC 01' },
    { codigo: '84716052', descricao: 'Teclados de computador', aliquotaIpi: 10, unidadeTributavel: 'UN', fonteLegal: 'TIPI 2024' },
  ];

  for (const ncm of ncms) {
    await prisma.ncm.upsert({
      where: { codigo: ncm.codigo },
      update: {},
      create: { ...ncm, validoDesde: new Date('2024-01-01') },
    });
  }
  console.log(`✅ ${ncms.length} NCMs base criados`);

  console.log('\n🎉 Seed concluído! Dados para login:');
  console.log('   Email: dev@berith.com.br');
  console.log('   Senha: senha123');
}

main()
  .catch((e) => { console.error('❌ Erro no seed:', e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
