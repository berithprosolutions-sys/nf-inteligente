// FEATURE: core/database
// Responsabilidade: Instância global do PrismaClient com lifecycle correto
// NÃO faz: Queries diretamente — use via services de cada feature
import { PrismaClient } from '@prisma/client';

declare global {
  // Previne múltiplas instâncias em hot-reload do tsx
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma =
  globalThis.__prisma ??
  new PrismaClient({
    log:
      process.env.NODE_ENV === 'development'
        ? ['query', 'error', 'warn']
        : ['error'],
  });

if (process.env.NODE_ENV !== 'production') {
  globalThis.__prisma = prisma;
}
