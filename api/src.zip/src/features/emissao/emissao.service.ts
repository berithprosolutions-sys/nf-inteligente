// FEATURE: emissao
// Responsabilidade: Lógica de negócio para emissão de NF-e e NFS-e
// Fase 3: Emissão simulada com persistência real no banco PostgreSQL
import { Decimal } from '@prisma/client/runtime/library';
import { Prisma } from '@prisma/client';
import { prisma } from '../../lib/prisma.js';
import { NotFoundError } from '../../lib/errors.js';
import type { EmitirNotaDTO } from './emissao.schema.js';

export class EmissaoService {
  /**
   * Emite uma nota fiscal simulada (Fase 3 — sem SEFAZ real)
   * Persiste no banco com status 'autorizada' e gera chave de acesso simulada
   */
  async emitir(empresaId: string, dto: EmitirNotaDTO) {
    // Validar cliente pertence à empresa
    const cliente = await prisma.cliente.findFirst({
      where: { id: dto.clienteId, empresaId, deletadoEm: null },
    });
    if (!cliente) throw new NotFoundError('Cliente');

    // Calcular totais
    const valorTotal = dto.itens.reduce((acc, item) => {
      return acc + item.quantidade * item.valorUnitario;
    }, 0);

    // Gerar chave de acesso simulada (44 dígitos)
    const chaveAcesso = this.gerarChaveAcessoSimulada(empresaId, dto.tipo);

    // Persistir a nota com itens em transação atômica
    const nota = await prisma.$transaction(async (tx) => {
      const notaCriada = await tx.notaFiscal.create({
        data: {
          empresaId,
          clienteId: dto.clienteId,
          tipo: dto.tipo,
          status: 'autorizada',
          naturezaOperacao: dto.naturezaOperacao,
          valorTotal: new Decimal(valorTotal),
          valorDesconto: new Decimal(0),
          simulada: true,
          chaveAcesso,
          numero: String(Math.floor(Math.random() * 900000) + 100000),
          serie: '001',
        },
      });

      await tx.itemNotaFiscal.createMany({
        data: dto.itens.map((item) => ({
          notaFiscalId: notaCriada.id,
          produtoId: item.produtoId ?? null,
          servicoId: item.servicoId ?? null,
          descricao: item.descricao,
          quantidade: new Decimal(item.quantidade),
          valorUnitario: new Decimal(item.valorUnitario),
          valorTotal: new Decimal(item.quantidade * item.valorUnitario),
          ncm: item.ncm ?? null,
          cfop: item.cfop ?? null,
          impostos: (item.impostos ?? {}) as Prisma.InputJsonValue,
        })),
      });

      return notaCriada;
    });

    return nota;
  }

  async listar(empresaId: string, page = 1, perPage = 20) {
    const skip = (page - 1) * perPage;
    const [data, total] = await Promise.all([
      prisma.notaFiscal.findMany({
        where: { empresaId, deletadoEm: null },
        include: { cliente: { select: { nome: true, documento: true } } },
        orderBy: { criadoEm: 'desc' },
        skip,
        take: perPage,
      }),
      prisma.notaFiscal.count({ where: { empresaId, deletadoEm: null } }),
    ]);
    return { data, total };
  }

  async buscarPorId(id: string, empresaId: string) {
    const nota = await prisma.notaFiscal.findFirst({
      where: { id, empresaId, deletadoEm: null },
      include: {
        cliente: true,
        itens: true,
      },
    });
    if (!nota) throw new NotFoundError('Nota Fiscal');
    return nota;
  }

  async cancelar(id: string, empresaId: string, motivo: string) {
    const nota = await this.buscarPorId(id, empresaId);
    if (nota.status !== 'autorizada') {
      throw new Error('Apenas notas autorizadas podem ser canceladas');
    }
    return prisma.notaFiscal.update({
      where: { id },
      data: { status: 'cancelada', motivoCancelamento: motivo },
    });
  }

  async getKpis(empresaId: string) {
    const now = new Date();
    const inicioMes = new Date(now.getFullYear(), now.getMonth(), 1);

    const [faturamentoResult, totalNotas, notasMes] = await Promise.all([
      prisma.notaFiscal.aggregate({
        where: { empresaId, status: 'autorizada', criadoEm: { gte: inicioMes } },
        _sum: { valorTotal: true },
        _count: true,
      }),
      prisma.notaFiscal.count({ where: { empresaId, status: 'autorizada' } }),
      prisma.notaFiscal.count({
        where: { empresaId, status: 'autorizada', criadoEm: { gte: inicioMes } },
      }),
    ]);

    const faturamentoMes = Number(faturamentoResult._sum.valorTotal ?? 0);

    return {
      faturamentoMes,
      notasEmitidas: totalNotas,
      notasEstesMes: notasMes,
      // Economia IA: estimativa de 3% do faturamento (placeholder até Fase 4)
      economiaIA: faturamentoMes * 0.03,
    };
  }

  private gerarChaveAcessoSimulada(empresaId: string, tipo: string): string {
    const cUF = '35'; // SP
    const AAMM = new Date().toISOString().slice(2, 7).replace('-', '');
    const mod = tipo === 'NFe' ? '55' : '99';
    const rand = Math.floor(Math.random() * 1e9).toString().padStart(9, '0');
    const base = `${cUF}${AAMM}12345678000199${mod}001${rand}`;
    // Preencher até 44 caracteres
    return base.padEnd(44, '0').slice(0, 44);
  }
}
